import ProductList from "./components/ProductList";

export default function ProductPage() {
  return <ProductList />;
}
