import ProductDetail from "../components/ProductDetail";

export default function ProductPage({ params }) {
  return (
    <div className="container py-4">
      <ProductDetail />
    </div>
  );
}
